//
//  GrayColorNavigationBar.h
//  SupTaxi
//
//  Created by Igor Novik on 8/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (GrayColorNavigationBar)

@end
