//
//  NO Copyright 2010 MightyLittle Industries. NO rights reserved.
//
//  Use this code any way you like. If you do like it, please
//  link to my blog and/or write a friendly comment. Thank you!
//
//  Read my blog @ http://blog.sallarp.com
//

#import <Foundation/Foundation.h>

@interface NSString (URLEncode)
- (NSString *)URLEncodedString;
@end